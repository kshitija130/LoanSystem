﻿
namespace LoanSystem
{
    partial class UserPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Apply = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.AllLoan = new System.Windows.Forms.Button();
            this.txtuser = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // Apply
            // 
            this.Apply.Location = new System.Drawing.Point(25, 58);
            this.Apply.Name = "Apply";
            this.Apply.Size = new System.Drawing.Size(75, 23);
            this.Apply.TabIndex = 0;
            this.Apply.Text = "Apply";
            this.Apply.UseVisualStyleBackColor = true;
            this.Apply.Click += new System.EventHandler(this.Apply_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(12, 154);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(578, 151);
            this.dataGridView2.TabIndex = 1;
            // 
            // AllLoan
            // 
            this.AllLoan.Location = new System.Drawing.Point(193, 58);
            this.AllLoan.Name = "AllLoan";
            this.AllLoan.Size = new System.Drawing.Size(75, 23);
            this.AllLoan.TabIndex = 2;
            this.AllLoan.Text = "AllLoan";
            this.AllLoan.UseVisualStyleBackColor = true;
            this.AllLoan.Click += new System.EventHandler(this.AllLoan_Click);
            // 
            // txtuser
            // 
            this.txtuser.Location = new System.Drawing.Point(483, 24);
            this.txtuser.Name = "txtuser";
            this.txtuser.Size = new System.Drawing.Size(100, 20);
            this.txtuser.TabIndex = 3;
            // 
            // UserPage
            // 
            this.ClientSize = new System.Drawing.Size(602, 368);
            this.Controls.Add(this.txtuser);
            this.Controls.Add(this.AllLoan);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.Apply);
            this.Name = "UserPage";
            this.Load += new System.EventHandler(this.UserPage_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem applyForLoanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trackLoanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allLoanToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.Button Apply;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button AllLoan;
        private System.Windows.Forms.TextBox txtuser;
    }
}