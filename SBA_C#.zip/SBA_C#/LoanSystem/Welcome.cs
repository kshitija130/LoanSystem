﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanSystem
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void Admin_Click(object sender, EventArgs e)
        {
            AdminLogin adminlogin = new AdminLogin();
            adminlogin.MdiParent = Welcome.ActiveForm;
           
            adminlogin.Show();
        }

        private void maneger_Click(object sender, EventArgs e)
        {
            ManagerLogin managrlogin = new ManagerLogin();
            managrlogin.MdiParent = Welcome.ActiveForm;

            managrlogin.Show();

        }

        private void User_Click(object sender, EventArgs e)
        {
            UserLogin userlogin = new UserLogin();
            userlogin.MdiParent = Welcome.ActiveForm;
            userlogin.Show();
        }

        private void Welcome_Load(object sender, EventArgs e)
        {

        }
    }
}
