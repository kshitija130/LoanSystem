﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanSystem
{
    public partial class UserPage : Form
    {
        SqlConnection conn;
        SqlDataAdapter adp;
        DataSet data;
        DataTable table;
        public UserPage(string username)
        {
            InitializeComponent();
         
            txtuser.Text = username;
          
        }

        

       

      private void trackLoanToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void menuStrip_ItemClicked(object sender, EventArgs e)
        {
           
        }
        private void allLoanToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void applyForLoanToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void UserPage_Load(object sender, EventArgs e)
        {

        }

        private void Apply_Click(object sender, EventArgs e)
        {

            ApplyLoan p = new ApplyLoan(txtuser.Text);
            p.Show();
        }

        private void AllLoan_Click(object sender, EventArgs e)
        {

            try
            {
                string user = txtuser.Text;
                conn = new SqlConnection(@"Data Source=SONAL\SQLEXPRESS;integrated security=SSPI;initial catalog=Loan");
                conn.Open();
                SqlCommand cmd = new SqlCommand("select * from LoanApply where Username=@user", conn);
                cmd.Parameters.AddWithValue("user", user);
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                dataGridView2.DataSource = dt;
                conn.Close();
            }
            catch (SqlException p)
            {
                MessageBox.Show(p.Message);
            }
        }

        private void UserPage_Load_1(object sender, EventArgs e)
        {

        }
    }
}
