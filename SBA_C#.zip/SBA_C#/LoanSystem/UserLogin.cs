﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanSystem
{
    public partial class UserLogin : Form
    {
        public UserLogin()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "" || txtPassword.Text == "")
            {
                MessageBox.Show("please enter Username and Password");
            }

            else
            {
                try
                {
                    SqlConnection sqlConnection;
                    //  SqlCommand command;
                    sqlConnection = new SqlConnection(@"Data Source=SONAL\SQLEXPRESS;integrated security=SSPI;initial catalog=Loan");
                    sqlConnection.Open();
                    SqlCommand CheckUserExit = new SqlCommand("select count(*) From [UserRegister] where([UserName] = @user and ([Password] = @password))", sqlConnection);
                    CheckUserExit.Parameters.AddWithValue("@user", txtUsername.Text);
                    CheckUserExit.Parameters.AddWithValue("@password", txtPassword.Text);
                    int UserExit = (int)CheckUserExit.ExecuteScalar();

                    if (UserExit > 0)
                    {
                        UserPage p = new UserPage(txtUsername.Text);
                        p.Show();
                    }
                    else
                    {
                        MessageBox.Show("user doesnt exits or wrong id password");
                    }
                    sqlConnection.Close();
                }
                catch(SqlException e1)
                {
                    MessageBox.Show(e1.Message);
                }
            }

          
        }

        private void Resgiter_Click(object sender, EventArgs e)
        {
            UserRegister r = new UserRegister();
            r.Show();
        }

        private void UserLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
