﻿
namespace LoanSystem
{
    partial class Managerp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtLoanId = new System.Windows.Forms.TextBox();
            this.txtremarks = new System.Windows.Forms.RichTextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Submit = new System.Windows.Forms.Button();
            this.previous = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(75, 41);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(635, 233);
            this.dataGridView1.TabIndex = 0;
            // 
            // txtLoanId
            // 
            this.txtLoanId.Location = new System.Drawing.Point(75, 312);
            this.txtLoanId.Name = "txtLoanId";
            this.txtLoanId.Size = new System.Drawing.Size(100, 20);
            this.txtLoanId.TabIndex = 1;
            // 
            // txtremarks
            // 
            this.txtremarks.Location = new System.Drawing.Point(231, 297);
            this.txtremarks.Name = "txtremarks";
            this.txtremarks.Size = new System.Drawing.Size(100, 96);
            this.txtremarks.TabIndex = 2;
            this.txtremarks.Text = "";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Accepted",
            "Rejected"});
            this.comboBox1.Location = new System.Drawing.Point(413, 297);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Submit
            // 
            this.Submit.Location = new System.Drawing.Point(626, 294);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(75, 23);
            this.Submit.TabIndex = 4;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // previous
            // 
            this.previous.Location = new System.Drawing.Point(45, 354);
            this.previous.Name = "previous";
            this.previous.Size = new System.Drawing.Size(75, 39);
            this.previous.TabIndex = 5;
            this.previous.Text = "prvious";
            this.previous.UseVisualStyleBackColor = true;
            this.previous.Click += new System.EventHandler(this.previous_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(140, 354);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 39);
            this.button3.TabIndex = 6;
            this.button3.Text = "next";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Managerp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.previous);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.txtremarks);
            this.Controls.Add(this.txtLoanId);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Managerp";
            this.Text = "Managerp";
            this.Load += new System.EventHandler(this.Managerp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtLoanId;
        private System.Windows.Forms.RichTextBox txtremarks;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.Button previous;
        private System.Windows.Forms.Button button3;
    }
}