﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanSystem
{
    public partial class AdminLogin : Form
    {
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            if(txtusername.Text=="Admin"&& txtPassword.Text=="pass")
            {
                ManagerRegister m = new ManagerRegister();
                m.Show();
            }
            else
            {
                MessageBox.Show("invalid input");
            }
        }
    }
}
