﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanSystem
{
    public partial class ManagerLogin : Form
    {
        public ManagerLogin()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "" || txtPassword.Text == "")
            {
                MessageBox.Show("please enter Username and Password");
            }

            else
            {
                SqlConnection sqlConnection=null;
                //  SqlCommand command;
                sqlConnection = new SqlConnection(@"Data Source=SONAL\SQLEXPRESS;integrated security=SSPI;initial catalog=Loan");
                sqlConnection.Open();
                SqlCommand CheckUserExit = new SqlCommand("select count(*) From [Manager] where([UserName] = @user and ([Password] = @password))", sqlConnection);
                CheckUserExit.Parameters.AddWithValue("@user", txtUsername.Text);
                CheckUserExit.Parameters.AddWithValue("@password", txtPassword.Text);
                int UserExit = (int)CheckUserExit.ExecuteScalar();

                if (UserExit > 0)
                {
                    Managerp p = new Managerp();
                    p.Show();
                }
                else
                {
                    MessageBox.Show("user doesnt exits or wrong id password");
                }
                sqlConnection.Close();
            }
        }

        private void ManagerLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
