﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanSystem
{
    public partial class UserRegister : Form
    {
        public UserRegister()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection;
            SqlCommand cmd;
            SqlDataReader dr;
            sqlConnection = new SqlConnection(@"Data Source=SONAL\SQLEXPRESS;integrated security=SSPI;initial catalog=Loan");
            sqlConnection.Open();
            if (txtConfirmPassword.Text != string.Empty || txtpassword.Text != string.Empty || txtUsername.Text != string.Empty || txtPhone.Text == "")
            {

                if (txtpassword.Text == txtConfirmPassword.Text)
                {
                    cmd = new SqlCommand("select * from UserRegister where Username='" + txtUsername.Text + "'", sqlConnection);
                    
                    dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        dr.Close();
                        MessageBox.Show("Username Already exist please try another ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        if (txtFirstName.TextLength > 3 && txtLastName.TextLength < 10 && txtPhone.TextLength==10 && txtLastName.TextLength>3 &&txtLastName.TextLength<10)
                            {
                            //convert values into required type nd call constructor and pass the values or insert from here
                            dr.Close();
                            cmd = new SqlCommand("insert into UserRegister values(@FirstName,@LastName,@Phone,@Adress,@email,@Username,@password)", sqlConnection);
                            MessageBox.Show(txtUsername.Text);//enter all values
                            cmd.Parameters.AddWithValue("FirstName", txtFirstName.Text);
                            cmd.Parameters.AddWithValue("LastName", txtLastName.Text);
                            cmd.Parameters.AddWithValue("Phone", txtPhone.Text);
                            cmd.Parameters.AddWithValue("Adress", txtAdress.Text);
                            cmd.Parameters.AddWithValue("email", txtEmail.Text);
                            cmd.Parameters.AddWithValue("Username", txtUsername.Text);
                            cmd.Parameters.AddWithValue("password", txtpassword.Text);
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Your Account is created . Please login now.", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter both password same ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            else
            {
                MessageBox.Show("Please enter value in all field.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            sqlConnection.Close();
        }

        private void UserRegister_Load(object sender, EventArgs e)
        {

        }
    }
}
