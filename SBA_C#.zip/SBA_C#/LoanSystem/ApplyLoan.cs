﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanSystem
{
    public partial class ApplyLoan : Form
    {
        public ApplyLoan(string username)
        {
            InitializeComponent();
            txtUsername.Text = username;
        }

        private void Apply_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection;
            SqlCommand cmd;
            SqlDataReader dr;
            sqlConnection = new SqlConnection(@"Data Source=SONAL\SQLEXPRESS;integrated security=SSPI;initial catalog=Loan");
            sqlConnection.Open();
            if (txtLoanName.Text != string.Empty || txtLoanAmount.Text != string.Empty || txtemail.Text != string.Empty || txtAdress.Text == "")
            {

                         
                                             
               cmd = new SqlCommand("insert into LoanApply(LoanAmount,LoanName,LoanDate,BusninessStructar,TaxIndicator,BillingInicator,Username)  values(@LoanAmount,@LoanName,@LoanDate,@BusninessStructar,@TaxIndicator,@BillingInicator,@username)", sqlConnection);//enter all values
                        cmd.Parameters.AddWithValue("LoanAmount", txtLoanAmount.Text);
                        cmd.Parameters.AddWithValue("LoanName", txtLoanName.Text);
                        cmd.Parameters.AddWithValue("LoanDate", dateTimePicker1.Text);
                        cmd.Parameters.AddWithValue("BusninessStructar", comboBox_Bussniess.Text);
                        cmd.Parameters.AddWithValue("TaxIndicator", comboBox_tax.Text);

                        cmd.Parameters.AddWithValue("BillingInicator",comboBox_billing.Text);
                cmd.Parameters.AddWithValue("username", txtUsername.Text);
                cmd.ExecuteNonQuery();
                        MessageBox.Show("Your Account is created . Please login now.", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("enter all the feils");
            }

            sqlConnection.Close();
        }

        private void ApplyLoan_Load(object sender, EventArgs e)
        {

        }
    }

          

        
    }

