﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoanSystem
{
    public partial class Managerp : Form
    {
        private CurrencyManager myCurrencyManager;

        public Managerp()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Managerp_Load(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = null;
            SqlDataAdapter sqlDataAdapter = null;
            DataSet dataSet = null;
            DataTable dataTable = null;
    

            try
            {
                sqlConnection = new SqlConnection(@"Data Source=SONAL\SQLEXPRESS;integrated security=SSPI;initial catalog=Loan");
                sqlDataAdapter = new SqlDataAdapter("select * from LoanApply", sqlConnection);

                dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet, "Loan");
                dataTable = dataSet.Tables["Loan"];
                txtLoanId.DataBindings.Add("Text", dataTable,
                "LoanId");
                myCurrencyManager = (CurrencyManager)this.BindingContext[dataTable];
                myCurrencyManager.Position = 0;
                dataGridView1.DataSource = dataTable;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void previous_Click(object sender, EventArgs e)
        {

            myCurrencyManager.Position -= 1;
            txtremarks.Text = "";
            comboBox1.SelectedIndex = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {

            myCurrencyManager.Position += 1;
            txtremarks.Text = "";
            comboBox1.SelectedIndex = 0;

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            SqlCommand command = null;
            try
            {
               SqlConnection  sqlconnection = new SqlConnection(@"Data Source=SONAL\SQLEXPRESS;integrated security=SSPI;initial catalog=Loan");
                command = new SqlCommand("update LoanApply set LoanStatus=@loanstatus,Remarks = @remark where LoanId = @loanid", sqlconnection);

                sqlconnection.Open();
                command.Parameters.AddWithValue("@loanstatus",
               comboBox1.SelectedItem);
                command.Parameters.AddWithValue("@remark", txtremarks.Text);
                command.Parameters.AddWithValue("@loanid", txtLoanId.Text);
                command.ExecuteNonQuery();
                sqlconnection.Close();
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
           
        }
    }
}
